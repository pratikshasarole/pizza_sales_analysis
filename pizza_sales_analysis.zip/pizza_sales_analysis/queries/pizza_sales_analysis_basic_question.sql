use pizzahut;
-- Retrieve the total number of orders placed.
SELECT 
    COUNT(order_id) AS total_no_of_orders
FROM
    orders;
    
-- Calculate the total revenue generated from pizza sales.
SELECT 
    round(SUM(od.quantity * p.price),2) AS total_revenue_generated
FROM
    order_details od
        JOIN
    pizzas p ON od.pizza_id = p.pizza_id;

    
-- Identify the highest-priced pizza.
SELECT 
    p.pizza_id,
    pt.name,
    pt.category,
    p.size,
    p.price,
    pt.ingredients
FROM
    pizzas p
        JOIN
    pizza_types pt ON p.pizza_type_id = pt.pizza_type_id
ORDER BY p.price DESC
LIMIT 1;

-- Identify the most common pizza size ordered.
SELECT 
    p.size,
    SUM(od.quantity) AS total_quantity,
    COUNT(od.order_details_id) AS order_count
FROM
    pizzas p
        JOIN
    order_details od ON p.pizza_id = od.pizza_id
GROUP BY p.size
ORDER BY order_count;

-- List the top 5 most ordered pizza types along with their quantities.
SELECT 
    pt.pizza_type_id,
    pt.name,
    COUNT(od.quantity) AS most_ordered_pizza
FROM
    order_details od
        JOIN
    pizzas p ON od.pizza_id = p.pizza_id
        JOIN
    pizza_types pt ON p.pizza_type_id = pt.pizza_type_id
GROUP BY pt.pizza_type_id , pt.name
ORDER BY most_ordered_pizza DESC
LIMIT 5;

--









