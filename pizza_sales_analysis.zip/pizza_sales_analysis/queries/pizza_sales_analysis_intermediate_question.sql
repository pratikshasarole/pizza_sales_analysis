use pizzahut;
-- Join the necessary tables to find the total quantity of each pizza category ordered.
SELECT 
    pt.category, SUM(od.quantity) AS total_quantity
FROM
    order_details od
        JOIN
    pizzas p ON od.pizza_id = p.pizza_id
        JOIN
    pizza_types pt ON pt.pizza_type_id = p.pizza_type_id
GROUP BY pt.category
ORDER BY total_quantity DESC;

-- Determine the distribution of orders by hour of the day.
SELECT 
    HOUR(time) AS order_time, COUNT(order_id) AS order_count
FROM
    orders
GROUP BY order_time
ORDER BY order_count DESC;

-- Join relevant tables to find the category-wise distribution of pizzas.
SELECT 
    category, COUNT(name) AS total_subcategories
FROM
    pizza_types
GROUP BY category
ORDER BY total_subcategories;
-- Group the orders by date and calculate the average number of pizzas ordered per day.
SELECT 
    ROUND(AVG(order_quantity), 0) AS avg_no_of_orders_per_day
FROM
    (SELECT 
        o.date AS order_date, SUM(od.quantity) AS order_quantity
    FROM
        order_details od
    JOIN orders o ON od.order_id = o.order_id
    GROUP BY order_date) AS daily_orders;
    
    
    
    
    
-- Determine the top 3 most ordered pizza types based on revenue.
SELECT 
    p.pizza_type_id,
    pt.name,
    SUM(p.price * od.quantity) AS revenue
FROM
    pizza_types pt
        JOIN
    pizzas p ON pt.pizza_type_id = p.pizza_type_id
        JOIN
    order_details od ON od.pizza_id = p.pizza_id
GROUP BY p.pizza_type_id , pt.name
ORDER BY revenue DESC
LIMIT 3;

-- 
















